    
function nome(){
    window.prompt("Qual o seu nome?");
    
}  
function email(){
    window.prompt("Informe seu e-mail");
  
}
function datanasc(){
    window.prompt("Qual a sua data de nascimento?");
    
}
function cellp(){
    window.prompt("Qual o seu número de celular?");

}
function telefoners(){
    window.prompt("Qual o seu telefone residencial?");

}
