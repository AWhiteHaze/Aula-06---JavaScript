    
function clicou1(){
window.alert('Você escolheu a caixa de texto 1')
}
function clicou2(){
window.alert('Você escolheu a caixa de texto 2')
}
function clicou3(){
window.alert('Você escolheu a caixa de texto 3')
}
